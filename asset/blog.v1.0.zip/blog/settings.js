module.exports = { 
	cookieSecret: 'foreworld',
	db: 'foreworld',
	host: '127.0.0.1',
	port: 27017,
	user: 'sa',
	pass: 'xiang123',
	cdn: 'http://www.foreworld.net/js/'
};